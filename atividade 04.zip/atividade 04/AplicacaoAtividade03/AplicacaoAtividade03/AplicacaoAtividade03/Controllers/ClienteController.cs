﻿using AplicacaoAtividade03.DTOs;
using AplicacaoAtividade03.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AplicacaoAtividade03.Controllers
{
    // CLIENTES = TABELA pessoa (QUEM NAO E FUNCIONARIO). ROTA CONFORME O ROTEIRO: /api/pessoas
    [Route("api/pessoas")]
    [ApiController]
    public class ClienteController : ControllerBase
    {
        private readonly BdAulaBackendContext _context;

        public ClienteController(BdAulaBackendContext context)
        {
            _context = context;
        }

        // MONTA A RESPOSTA PADRAO DO CLIENTE (CPF COM OS ZEROS A ESQUERDA QUE O BIGINT PERDE)
        private static object ConverterParaResposta(Pessoa pessoa)
        {
            return new
            {
                idPessoa = pessoa.Idpessoa,
                nome = pessoa.Nome,
                cpf = pessoa.Cpf.ToString().PadLeft(11, '0'),
                dataNascimento = pessoa.DataNascimento,
                sexo = pessoa.Sexo,
                email = pessoa.Email,
                telefone = pessoa.Telefone.ToString(),
                ativoPessoa = pessoa.AtivoPessoa,

                enderecos = pessoa.Enderecos.Select(e => new
                {
                    idEndereco = e.Idendereco,
                    cep = e.Cep,
                    numero = e.Numero,
                    complemento = e.Complemento
                }).ToList()
            };
        }

        // VALIDA OS DADOS DO CLIENTE (USADO NO POST E NO PUT). RETORNA A MENSAGEM DE ERRO OU null
        private static string? ValidarCliente(ClienteDTO dto)
        {
            var hoje = DateOnly.FromDateTime(DateTime.Today);

            if (string.IsNullOrWhiteSpace(dto.Nome) || dto.Nome.Length > 100)
                return "INFORME UM NOME VALIDO.";

            if (dto.CPF == null || dto.CPF.Length != 11 || !dto.CPF.All(char.IsDigit))
                return "CPF DEVE POSSUIR 11 DIGITOS.";

            if (dto.DataNascimento == null || dto.DataNascimento > hoje)
                return "INFORME UMA DATA DE NASCIMENTO VALIDA.";

            if (dto.Sexo != "M" && dto.Sexo != "F")
                return "SEXO DEVE SER M OU F.";

            if (string.IsNullOrWhiteSpace(dto.Email) || !dto.Email.Contains('@') || dto.Email.Length > 100)
                return "INFORME UM EMAIL VALIDO.";

            if (dto.Telefone == null || dto.Telefone.Length < 10 || dto.Telefone.Length > 11 || !dto.Telefone.All(char.IsDigit))
                return "TELEFONE DEVE POSSUIR 10 OU 11 DIGITOS.";

            if (dto.Enderecos == null || dto.Enderecos.Count == 0)
                return "INFORME PELO MENOS UM ENDERECO.";

            foreach (var endereco in dto.Enderecos)
            {
                if (endereco.CEP == null || endereco.CEP.Length != 8 || !endereco.CEP.All(char.IsDigit))
                    return "CEP DEVE POSSUIR 8 DIGITOS.";

                if (string.IsNullOrWhiteSpace(endereco.Numero) || endereco.Numero.Length > 10)
                    return "INFORME UM NUMERO DE ENDERECO VALIDO.";

                if (endereco.Complemento != null && endereco.Complemento.Length > 150)
                    return "COMPLEMENTO DEVE TER NO MAXIMO 150 CARACTERES.";
            }

            return null;
        }

        // LISTAR OS CLIENTES (RF09). FILTRO OPCIONAL: ?nome=
        // CLIENTE = PESSOA QUE NAO E FUNCIONARIO
        [HttpGet]
        public async Task<IActionResult> GetClientes([FromQuery] string? nome)
        {
            var consulta = _context.Pessoas
                .AsNoTracking()
                .Include(p => p.Enderecos)
                .Where(p => p.Funcionario == null);

            if (!string.IsNullOrWhiteSpace(nome))
            {
                consulta = consulta.Where(p => p.Nome.Contains(nome));
            }

            var pessoas = await consulta.OrderBy(p => p.Nome).ToListAsync();

            return Ok(pessoas.Select(ConverterParaResposta));
        }

        // CONSULTAR UM CLIENTE E SEUS ENDERECOS
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetCliente(int id)
        {
            var pessoa = await _context.Pessoas
                .Include(p => p.Enderecos)
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.Idpessoa == id);

            if (pessoa == null)
            {
                return NotFound(new
                {
                    mensagem = "CLIENTE NAO LOCALIZADO."
                });
            }

            return Ok(ConverterParaResposta(pessoa));
        }

        // CONSULTAR OS PEDIDOS DE UM CLIENTE (TELA "MEUS PEDIDOS"). SO DEVOLVE PEDIDOS DESTE CLIENTE
        [HttpGet("{id:int}/pedidos")]
        public async Task<ActionResult<IEnumerable<AtendimentoListDTO>>> GetPedidosDoCliente(int id)
        {
            if (!await _context.Pessoas.AnyAsync(p => p.Idpessoa == id))
            {
                return NotFound(new
                {
                    mensagem = "CLIENTE NAO LOCALIZADO."
                });
            }

            var pedidos = await _context.Atendimentos
                .AsNoTracking()
                .Where(a => a.Idpessoa == id)
                .OrderByDescending(a => a.Idatendimento)
                .ProjetarPedidos()
                .ToListAsync();

            return Ok(pedidos);
        }

        // IDENTIFICAR O CLIENTE (O SISTEMA NAO TEM SENHA): E-MAIL + CPF DEVEM PERTENCER A MESMA PESSOA
        [HttpPost("identificar")]
        public async Task<IActionResult> Identificar(ClienteIdentificarDTO dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Email) ||
                dto.CPF == null || dto.CPF.Length != 11 || !dto.CPF.All(char.IsDigit))
            {
                return BadRequest(new
                {
                    mensagem = "INFORME O E-MAIL E O CPF (11 DIGITOS)."
                });
            }

            ulong cpf = ulong.Parse(dto.CPF);
            var email = dto.Email.Trim();

            var pessoa = await _context.Pessoas
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.Cpf == cpf && p.Email == email);

            if (pessoa == null)
            {
                return NotFound(new
                {
                    mensagem = "NAO ENCONTRAMOS CADASTRO COM ESSE E-MAIL E CPF."
                });
            }

            return Ok(new
            {
                idPessoa = pessoa.Idpessoa,
                nome = pessoa.Nome
            });
        }

        // CADASTRAR CLIENTE
        [HttpPost]
        public async Task<IActionResult> PostCliente(ClienteDTO dto)
        {
            var erroValidacao = ValidarCliente(dto);
            if (erroValidacao != null)
            {
                return BadRequest(new { mensagem = erroValidacao });
            }

            ulong cpf = ulong.Parse(dto.CPF!);

            if (await _context.Pessoas.AnyAsync(p => p.Cpf == cpf))
            {
                return Conflict(new
                {
                    mensagem = "JA EXISTE UMA PESSOA CADASTRADA COM ESSE CPF."
                });
            }

            if (await _context.Pessoas.AnyAsync(p => p.Email == dto.Email))
            {
                return Conflict(new
                {
                    mensagem = "JA EXISTE UMA PESSOA CADASTRADA COM ESSE EMAIL."
                });
            }

            var pessoa = new Pessoa
            {
                Nome = dto.Nome!,
                Cpf = cpf,
                DataNascimento = dto.DataNascimento!.Value,
                Sexo = dto.Sexo!,
                Email = dto.Email!,
                Telefone = ulong.Parse(dto.Telefone!),
                AtivoPessoa = "S",

                Enderecos = dto.Enderecos.Select(e => new Endereco
                {
                    Cep = e.CEP!,
                    Numero = e.Numero!,
                    Complemento = e.Complemento ?? ""
                }).ToList()
            };

            _context.Pessoas.Add(pessoa);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new
                {
                    mensagem = "ERRO AO CADASTRAR CLIENTE.",
                    erro = ex.InnerException?.Message ?? ex.Message
                });
            }

            return CreatedAtAction(
                nameof(GetCliente),
                new { id = pessoa.Idpessoa },
                new
                {
                    idPessoa = pessoa.Idpessoa,
                    nome = pessoa.Nome,
                    mensagem = "CLIENTE CADASTRADO COM SUCESSO."
                }
            );
        }

        // ALTERAR CLIENTE E ENDERECOS (EDICAO PEDIDA NO ROTEIRO)
        // ENDERECO COM IdEndereco = ATUALIZA / SEM IdEndereco = NOVO / O QUE NAO VIER NA LISTA E REMOVIDO
        [HttpPut("{id:int}")]
        public async Task<IActionResult> PutCliente(int id, ClienteDTO dto)
        {
            var erroValidacao = ValidarCliente(dto);
            if (erroValidacao != null)
            {
                return BadRequest(new { mensagem = erroValidacao });
            }

            var pessoa = await _context.Pessoas
                .Include(p => p.Enderecos)
                .FirstOrDefaultAsync(p => p.Idpessoa == id);

            if (pessoa == null)
            {
                return NotFound(new
                {
                    mensagem = "CLIENTE NAO LOCALIZADO."
                });
            }

            ulong cpf = ulong.Parse(dto.CPF!);

            if (await _context.Pessoas.AnyAsync(p => p.Cpf == cpf && p.Idpessoa != id))
            {
                return Conflict(new { mensagem = "OUTRA PESSOA JA USA ESSE CPF." });
            }

            if (await _context.Pessoas.AnyAsync(p => p.Email == dto.Email && p.Idpessoa != id))
            {
                return Conflict(new { mensagem = "OUTRA PESSOA JA USA ESSE EMAIL." });
            }

            var idsEnviados = dto.Enderecos
                .Where(e => e.IdEndereco.HasValue)
                .Select(e => e.IdEndereco!.Value)
                .ToList();

            if (idsEnviados.Any(i => !pessoa.Enderecos.Any(x => x.Idendereco == i)))
            {
                return BadRequest(new
                {
                    mensagem = "EXISTE ENDERECO INFORMADO QUE NAO PERTENCE A ESTE CLIENTE."
                });
            }

            pessoa.Nome = dto.Nome!;
            pessoa.Cpf = cpf;
            pessoa.DataNascimento = dto.DataNascimento!.Value;
            pessoa.Sexo = dto.Sexo!;
            pessoa.Email = dto.Email!;
            pessoa.Telefone = ulong.Parse(dto.Telefone!);

            var removidos = pessoa.Enderecos
                .Where(e => !idsEnviados.Contains(e.Idendereco))
                .ToList();

            _context.Enderecos.RemoveRange(removidos);

            foreach (var e in dto.Enderecos)
            {
                if (e.IdEndereco.HasValue)
                {
                    var existente = pessoa.Enderecos.First(x => x.Idendereco == e.IdEndereco.Value);
                    existente.Cep = e.CEP!;
                    existente.Numero = e.Numero!;
                    existente.Complemento = e.Complemento ?? "";
                }
                else
                {
                    pessoa.Enderecos.Add(new Endereco
                    {
                        Cep = e.CEP!,
                        Numero = e.Numero!,
                        Complemento = e.Complemento ?? ""
                    });
                }
            }

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new
                {
                    mensagem = "ERRO AO ALTERAR CLIENTE.",
                    erro = ex.InnerException?.Message ?? ex.Message
                });
            }

            return NoContent();
        }
    }
}
