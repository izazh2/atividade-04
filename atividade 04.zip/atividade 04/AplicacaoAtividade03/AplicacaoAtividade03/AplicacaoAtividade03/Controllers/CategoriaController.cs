﻿using AplicacaoAtividade03.DTOs;
using AplicacaoAtividade03.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AplicacaoAtividade03.Controllers
{
    // CRUD DE CATEGORIAS (RF12): /api/categorias
    [Route("api/categorias")]
    [ApiController]
    public class CategoriaController : ControllerBase
    {
        private readonly BdAulaBackendContext _context;

        public CategoriaController(BdAulaBackendContext context)
        {
            _context = context;
        }

        private static string? ValidarNome(string? categoria)
        {
            if (string.IsNullOrWhiteSpace(categoria))
                return "INFORME O NOME DA CATEGORIA.";

            if (categoria.Trim().Length > 35)
                return "NOME DA CATEGORIA COM NO MAXIMO 35 CARACTERES.";

            return null;
        }

        // LISTAR TODAS AS CATEGORIAS
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CategoriaListDTO>>> GetCategorias()
        {
            var categorias = await _context.Categoria
                .AsNoTracking()
                .OrderBy(c => c.Categoria)
                .Select(c => new CategoriaListDTO
                {
                    IdCategoria = c.Idcategoria,
                    Categoria = c.Categoria,
                    QuantidadeItens = c.Items.Count()
                })
                .ToListAsync();

            return Ok(categorias);
        }

        // CONSULTAR UMA CATEGORIA
        [HttpGet("{id:int}")]
        public async Task<ActionResult<CategoriaListDTO>> GetCategoria(int id)
        {
            var categoria = await _context.Categoria
                .AsNoTracking()
                .Where(c => c.Idcategoria == id)
                .Select(c => new CategoriaListDTO
                {
                    IdCategoria = c.Idcategoria,
                    Categoria = c.Categoria,
                    QuantidadeItens = c.Items.Count()
                })
                .FirstOrDefaultAsync();

            if (categoria == null)
            {
                return NotFound(new { mensagem = "CATEGORIA NAO LOCALIZADA!!!" });
            }

            return Ok(categoria);
        }

        // CADASTRAR CATEGORIA
        [HttpPost]
        public async Task<ActionResult<CategoriaListDTO>> PostCategoria(CategoriaDTO dto)
        {
            var erro = ValidarNome(dto.Categoria);
            if (erro != null)
            {
                return BadRequest(new { mensagem = erro });
            }

            var nome = dto.Categoria!.Trim();

            if (await _context.Categoria.AnyAsync(c => c.Categoria == nome))
            {
                return Conflict(new { mensagem = "JA EXISTE UMA CATEGORIA COM ESSE NOME." });
            }

            var categoria = new Categorium { Categoria = nome };
            _context.Categoria.Add(categoria);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new
                {
                    mensagem = "ERRO NO CADASTRO",
                    erro = ex.InnerException?.Message ?? ex.Message
                });
            }

            return CreatedAtAction(
                nameof(GetCategoria),
                new { id = categoria.Idcategoria },
                new CategoriaListDTO
                {
                    IdCategoria = categoria.Idcategoria,
                    Categoria = categoria.Categoria,
                    QuantidadeItens = 0
                });
        }

        // ALTERAR CATEGORIA
        [HttpPut("{id:int}")]
        public async Task<IActionResult> PutCategoria(int id, CategoriaDTO dto)
        {
            var erro = ValidarNome(dto.Categoria);
            if (erro != null)
            {
                return BadRequest(new { mensagem = erro });
            }

            var categoria = await _context.Categoria.FirstOrDefaultAsync(c => c.Idcategoria == id);
            if (categoria == null)
            {
                return NotFound(new { mensagem = "CATEGORIA NAO LOCALIZADA!!!" });
            }

            var nome = dto.Categoria!.Trim();

            if (await _context.Categoria.AnyAsync(c => c.Categoria == nome && c.Idcategoria != id))
            {
                return Conflict(new { mensagem = "JA EXISTE OUTRA CATEGORIA COM ESSE NOME." });
            }

            categoria.Categoria = nome;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new
                {
                    mensagem = "ERRO AO ALTERAR",
                    erro = ex.InnerException?.Message ?? ex.Message
                });
            }

            return NoContent();
        }

        // EXCLUIR CATEGORIA (SO SE NENHUM ITEM USAR A CATEGORIA - FK item -> categoria)
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteCategoria(int id)
        {
            var categoria = await _context.Categoria.FirstOrDefaultAsync(c => c.Idcategoria == id);
            if (categoria == null)
            {
                return NotFound(new { mensagem = "CATEGORIA NAO LOCALIZADA!!!" });
            }

            if (await _context.Items.AnyAsync(i => i.Idcategoria == id))
            {
                return Conflict(new
                {
                    mensagem = "CATEGORIA POSSUI PRODUTOS OU SERVICOS VINCULADOS E NAO PODE SER EXCLUIDA."
                });
            }

            _context.Categoria.Remove(categoria);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new
                {
                    mensagem = "ERRO AO EXCLUIR",
                    erro = ex.InnerException?.Message ?? ex.Message
                });
            }

            return NoContent();
        }
    }
}
