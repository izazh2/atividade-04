﻿using AplicacaoAtividade03.DTOs;
using AplicacaoAtividade03.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AplicacaoAtividade03.Controllers
{
    // CONSULTA DE ESTOQUE (RF18): /api/estoque E /api/estoque/{iditem}
    // O ESTOQUE NAO E ALTERADO POR AQUI: ELE SOBE COM AS ENTRADAS (POST /api/entradaprodutos)
    // E DESCE COM OS PEDIDOS (POST /api/pedidos), SEMPRE NO BACKEND
    [Route("api/estoque")]
    [ApiController]
    public class EstoqueController : ControllerBase
    {
        private readonly BdAulaBackendContext _context;

        public EstoqueController(BdAulaBackendContext context)
        {
            _context = context;
        }

        private IQueryable<EstoqueListDTO> ConsultaEstoque()
        {
            return _context.Estoques
                .AsNoTracking()
                .Select(e => new EstoqueListDTO
                {
                    IdItem = e.Iditem,
                    Item = e.IditemNavigation.IditemNavigation.Item1,
                    DescricaoItem = e.IditemNavigation.IditemNavigation.DescricaoItem,
                    Preco = e.IditemNavigation.IditemNavigation.Preco,
                    PrecoVenda = e.IditemNavigation.PrecoVenda,
                    Unidade = e.IditemNavigation.Unidade,
                    IdCategoria = e.IditemNavigation.IditemNavigation.Idcategoria,
                    Categoria = e.IditemNavigation.IditemNavigation.IdcategoriaNavigation.Categoria,
                    QuantidadeEstoque = e.QuantidadeEstoque,
                    AtivoProdutoServico = e.IditemNavigation.IditemNavigation.AtivoProdutoServico
                });
        }

        // LISTAR O ESTOQUE (TODOS OS PRODUTOS)
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EstoqueListDTO>>> GetEstoque()
        {
            var estoque = await ConsultaEstoque()
                .OrderBy(e => e.Item)
                .ToListAsync();

            return Ok(estoque);
        }

        // CONSULTAR O ESTOQUE DE UM PRODUTO PELO ID DO ITEM
        [HttpGet("{idItem:int}")]
        public async Task<ActionResult<EstoqueListDTO>> GetEstoquePorItem(int idItem)
        {
            var estoque = await ConsultaEstoque()
                .FirstOrDefaultAsync(e => e.IdItem == idItem);

            if (estoque == null)
            {
                return NotFound(new
                {
                    mensagem = "PRODUTO NAO LOCALIZADO NO ESTOQUE!!!"
                });
            }

            return Ok(estoque);
        }
    }
}
