﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using AplicacaoAtividade03.Models;
using AplicacaoAtividade03.DTOs;

namespace AplicacaoAtividade03.Controllers
{
    [ApiController]
    [Route("api/pedidos")]
    public class AtendimentoController : ControllerBase
    {
        //CRIANDO O ATRIBUTO _context
        private readonly BdAulaBackendContext _context;

        //Metodo construtor
        public AtendimentoController(BdAulaBackendContext context)
        {
            _context = context;
        }

        // ------------------------------------------------------------------
        // ADICIONADO: METODOS AUXILIARES (PRIVADOS) USADOS PELO POST E PELO PUT
        // ------------------------------------------------------------------

        // ADICIONADO: VALIDA OS ITENS RECEBIDOS (OBRIGATORIOS, QUANTIDADE, VALOR, REPETIDOS).
        // RETORNA A MENSAGEM DE ERRO OU null SE ESTIVER TUDO CERTO
        private static string? ValidarItens(List<(int IdItem, int IdFuncionario, int Quantidade, decimal ValorUnitario)> itens, bool exigirValor = true)
        {
            if (itens.Count == 0)
                return "INFORME PELO MENOS UM ITEM!!!";

            // A PK DE atendimentoitem E (idatendimento, iditem): O MESMO ITEM NAO PODE REPETIR
            if (itens.GroupBy(i => i.IdItem).Any(g => g.Count() > 1))
                return "O MESMO ITEM NAO PODE APARECER DUAS VEZES. SOME AS QUANTIDADES!!!";

            foreach (var i in itens)
            {
                if (i.IdItem <= 0)
                    return "INFORME O ID DO ITEM!!!";

                if (i.IdFuncionario <= 0)
                    return "INFORME O ID DO FUNCIONARIO RESPONSAVEL!!!";

                if (i.Quantidade <= 0)
                    return "A QUANTIDADE DEVE SER MAIOR QUE ZERO!!!";

                if (exigirValor && i.ValorUnitario <= 0)
                    return "O VALOR UNITARIO DEVE SER MAIOR QUE ZERO!!!";
            }

            return null;
        }

        // ADICIONADO: CONFERE SE OS ITENS E OS FUNCIONARIOS INFORMADOS EXISTEM (E SE O ITEM NOVO ESTA ATIVO).
        // RETORNA O ERRO HTTP OU null SE ESTIVER TUDO CERTO
        private async Task<ActionResult?> ValidarReferencias(
            List<(int IdItem, int IdFuncionario, int Quantidade, decimal ValorUnitario)> itens,
            HashSet<int> itensJaNoAtendimento)
        {
            foreach (var i in itens)
            {
                var item = await _context.Items
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x => x.Iditem == i.IdItem);

                if (item == null)
                {
                    return NotFound(new { mensagem = "ITEM " + i.IdItem + " NAO LOCALIZADO!!!" });
                }

                // SO EXIGE ITEM ATIVO PARA ITEM NOVO NO ATENDIMENTO
                if (!itensJaNoAtendimento.Contains(i.IdItem) && item.AtivoProdutoServico != "S")
                {
                    return Conflict(new { mensagem = "O ITEM '" + item.Item1 + "' ESTA INATIVO!!!" });
                }

                if (!await _context.Funcionarios.AnyAsync(f => f.Idpessoa == i.IdFuncionario))
                {
                    return NotFound(new { mensagem = "FUNCIONARIO " + i.IdFuncionario + " NAO LOCALIZADO!!!" });
                }
            }

            return null;
        }

        // ADICIONADO: SE O ITEM FOR PRODUTO ("P"), CONFERE SE TEM ESTOQUE PARA A QUANTIDADE PEDIDA.
        // (A TRIGGER TAMBEM CONFERE, MAS ASSIM A MENSAGEM FICA CLARA)
        private async Task<ActionResult?> ValidarEstoque(int idItem, int quantidade)
        {
            var item = await _context.Items
                .AsNoTracking()
                .FirstAsync(i => i.Iditem == idItem);

            if (item.TipoItem == "P")
            {
                var estoque = await _context.Estoques
                    .AsNoTracking()
                    .FirstOrDefaultAsync(e => e.Iditem == idItem);

                if (estoque == null || estoque.QuantidadeEstoque < quantidade)
                {
                    return Conflict(new { mensagem = "ESTOQUE INSUFICIENTE PARA O ITEM '" + item.Item1 + "'!!!" });
                }
            }

            return null;
        }

        // ------------------------------------------------------------------
        // ENDPOINTS
        // ------------------------------------------------------------------

        // LISTAR TODOS OS PEDIDOS (ATENDIMENTOS)
        // FILTROS OPCIONAIS: ?status=Aberto (OU A, P, F, C, "Em processamento", "Concluido", "Cancelado") E ?idPessoa=1
        // CORRIGIDO: O METODO ANTERIOR TINHA O PARAMETRO "object? atendimentos" E AGORA FILTRA POR STATUS (RF14)
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AtendimentoListDTO>>> GetAtendimentos(
            [FromQuery] string? status, [FromQuery] int? idPessoa)
        {
            var consulta = _context.Atendimentos.AsNoTracking();

            if (!string.IsNullOrWhiteSpace(status))
            {
                var codigo = PedidoProjecao.NormalizarStatus(status);

                if (codigo == null)
                {
                    return BadRequest(new
                    {
                        mensagem = "STATUS INVALIDO. USE: ABERTO, EM PROCESSAMENTO, CONCLUIDO OU CANCELADO."
                    });
                }

                consulta = consulta.Where(a => a.StatusAtendimento == codigo);
            }

            if (idPessoa.HasValue)
            {
                consulta = consulta.Where(a => a.Idpessoa == idPessoa.Value);
            }

            var pedidos = await consulta
                .OrderByDescending(a => a.Idatendimento)
                .ProjetarPedidos()
                .ToListAsync();

            return Ok(pedidos);
        }

        // CONSULTAR UM PEDIDO PELO ID
        // CORRIGIDO: O TIPO DE RETORNO ERA IEnumerable, MAS O METODO DEVOLVE UM UNICO REGISTRO.
        // TAMBEM CORRIGIDO: O NOME DO ITEM SAIA COMO DescricaoItem (NA LISTAGEM SAIA O NOME)
        [HttpGet("{id:int}")]
        public async Task<ActionResult<AtendimentoListDTO>> GetAtendimento(int id)
        {
            var pedido = await _context.Atendimentos
                .AsNoTracking()
                .Where(a => a.Idatendimento == id)
                .ProjetarPedidos()
                .FirstOrDefaultAsync();

            if (pedido == null)
            {
                return NotFound(new
                {
                    mensagem = "PEDIDO NAO LOCALIZADO!!!"
                });
            }

            return Ok(pedido);
        }

        // LISTAR OS PEDIDOS DE UM CLIENTE ESPECIFICO
        [HttpGet("pessoa/{idPessoa:int}")]
        public async Task<ActionResult<IEnumerable<AtendimentoListDTO>>> GetAtendimentosPorPessoa(int idPessoa)
        {
            var pessoaExiste = await _context.Pessoas
                .AnyAsync(p => p.Idpessoa == idPessoa);

            if (!pessoaExiste)
            {
                return NotFound(new
                {
                    mensagem = "CLIENTE NAO LOCALIZADO!!!"
                });
            }

            var pedidos = await _context.Atendimentos
                .AsNoTracking()
                .Where(a => a.Idpessoa == idPessoa)
                .OrderByDescending(a => a.Idatendimento)
                .ProjetarPedidos()
                .ToListAsync();

            return Ok(pedidos);
        }

        // INSERIR PEDIDO (ATENDIMENTO) COM OS ITENS
        [HttpPost]
        public async Task<ActionResult<AtendimentoListDTO>> PostAtendimento(AtendimentoPostDTO dto)
        {
            var pessoa = await _context.Pessoas
                .FirstOrDefaultAsync(p => p.Idpessoa == dto.IdPessoa);
            if (pessoa == null)
            {
                return NotFound(new
                {
                    mensagem = "Pessoa não localizada!!!"
                });
            }

            // VALIDACOES DOS ITENS (OBRIGATORIOS, QUANTIDADE, REPETIDOS). O VALOR UNITARIO NAO E EXIGIDO:
            // A API BUSCA O PRECO NO BANCO, ASSIM O FRONTEND NAO CONSEGUE GRAVAR UM PRECO DIFERENTE
            var itensRecebidos = dto.Itens
                .Select(i => (i.IdItem, i.IdFuncionario, i.Quantidade, i.ValorUnitario))
                .ToList();

            var erroValidacao = ValidarItens(itensRecebidos, exigirValor: false);
            if (erroValidacao != null)
            {
                return BadRequest(new { mensagem = erroValidacao });
            }

            // CONFERE SE OS ITENS E OS FUNCIONARIOS EXISTEM
            var erroReferencia = await ValidarReferencias(itensRecebidos, new HashSet<int>());
            if (erroReferencia != null)
            {
                return erroReferencia;
            }

            // CONFERE O ESTOQUE DOS PRODUTOS ANTES DE GRAVAR
            foreach (var i in itensRecebidos)
            {
                var erroEstoque = await ValidarEstoque(i.IdItem, i.Quantidade);
                if (erroEstoque != null)
                {
                    return erroEstoque;
                }
            }

            // PRECO REGISTRADO NO PEDIDO: PRODUTO = PRECO DE VENDA / SERVICO = PRECO DO ITEM
            var idsItens = dto.Itens.Select(i => i.IdItem).ToList();
            var itensBanco = await _context.Items
                .AsNoTracking()
                .Include(i => i.Produto)
                .Where(i => idsItens.Contains(i.Iditem))
                .ToListAsync();

            decimal PrecoDoItem(int idItem)
            {
                var itemBanco = itensBanco.First(x => x.Iditem == idItem);
                return itemBanco.TipoItem == "P" && itemBanco.Produto != null
                    ? itemBanco.Produto.PrecoVenda
                    : itemBanco.Preco;
            }

            var atendimento = new Atendimento
            {
                Idpessoa = dto.IdPessoa,
                DataAtendimento = dto.DataAtendimento ?? DateOnly.FromDateTime(DateTime.Today),
                // TODO PEDIDO NOVO NASCE ABERTO. O STATUS SO MUDA PELO ENDPOINT /status
                StatusAtendimento = "A",
                Atendimentoitems = dto.Itens
                    .Select(i => new Atendimentoitem
                    {
                        Iditem = i.IdItem,
                        Idfuncionario = i.IdFuncionario,
                        QuantidadeItens = i.Quantidade,
                        ValorunitarioEntrada = PrecoDoItem(i.IdItem)
                    }).ToList()
            };

            _context.Atendimentos.Add(atendimento);

            // SE A TRIGGER RECUSAR (EX.: FALTA DE ESTOQUE), NADA E GRAVADO
            // E A API RESPONDE COM A MENSAGEM DO BANCO EM VEZ DE ERRO 500 SEM EXPLICACAO
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new
                {
                    mensagem = "ERRO NO CADASTRO",
                    erro = ex.InnerException?.Message ?? ex.Message
                });
            }

            // CORRIGIDO: ANTES DEVOLVIA O DTO RECEBIDO (SEM O ID GERADO). AGORA DEVOLVE O PEDIDO GRAVADO
            var criado = await _context.Atendimentos
                .AsNoTracking()
                .Where(a => a.Idatendimento == atendimento.Idatendimento)
                .ProjetarPedidos()
                .FirstAsync();

            return CreatedAtAction(
                nameof(GetAtendimento),
                new { id = atendimento.Idatendimento },
                criado);
        }

        // ATUALIZAR A SITUACAO DO PEDIDO (RF15)
        // FLUXO: ABERTO -> EM PROCESSAMENTO -> CONCLUIDO. ABERTO OU EM PROCESSAMENTO PODEM SER CANCELADOS.
        // CONCLUIDO E CANCELADO SAO FINAIS. AO CANCELAR, OS PRODUTOS VOLTAM PARA O ESTOQUE.
        [HttpPut("{id:int}/status")]
        public async Task<IActionResult> PutStatus(int id, AtendimentoStatusDTO dto)
        {
            var novoStatus = PedidoProjecao.NormalizarStatus(dto.Status);

            if (novoStatus == null)
            {
                return BadRequest(new
                {
                    mensagem = "STATUS INVALIDO. USE: ABERTO, EM PROCESSAMENTO, CONCLUIDO OU CANCELADO."
                });
            }

            var atendimento = await _context.Atendimentos
                .Include(a => a.Atendimentoitems)
                    .ThenInclude(i => i.IditemNavigation)
                .FirstOrDefaultAsync(a => a.Idatendimento == id);

            if (atendimento == null)
            {
                return NotFound(new
                {
                    mensagem = "PEDIDO NAO LOCALIZADO!!!"
                });
            }

            var statusAtual = atendimento.StatusAtendimento;

            if (statusAtual == novoStatus)
            {
                return Conflict(new
                {
                    mensagem = "O PEDIDO JA ESTA COM A SITUACAO '" + PedidoProjecao.DescricaoStatus(statusAtual).ToUpper() + "'."
                });
            }

            var transicoesPermitidas = new Dictionary<string, string[]>
            {
                ["A"] = new[] { "P", "C" },
                ["P"] = new[] { "F", "C" },
                ["F"] = Array.Empty<string>(),
                ["C"] = Array.Empty<string>()
            };

            if (!transicoesPermitidas.TryGetValue(statusAtual, out var destinos) || !destinos.Contains(novoStatus))
            {
                return Conflict(new
                {
                    mensagem = "TRANSICAO NAO PERMITIDA: DE '" + PedidoProjecao.DescricaoStatus(statusAtual).ToUpper() +
                               "' PARA '" + PedidoProjecao.DescricaoStatus(novoStatus).ToUpper() + "'."
                });
            }

            // AO CANCELAR, DEVOLVE AO ESTOQUE OS PRODUTOS (A TRIGGER HAVIA BAIXADO NA CRIACAO DO PEDIDO)
            if (novoStatus == "C")
            {
                foreach (var item in atendimento.Atendimentoitems.Where(i => i.IditemNavigation.TipoItem == "P"))
                {
                    var estoque = await _context.Estoques
                        .FirstOrDefaultAsync(e => e.Iditem == item.Iditem);

                    if (estoque != null)
                    {
                        estoque.QuantidadeEstoque = estoque.QuantidadeEstoque + item.QuantidadeItens;
                    }
                }
            }

            atendimento.StatusAtendimento = novoStatus;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new
                {
                    mensagem = "ERRO AO ATUALIZAR A SITUACAO",
                    erro = ex.InnerException?.Message ?? ex.Message
                });
            }

            return Ok(new
            {
                idAtendimento = id,
                statusAtendimento = novoStatus,
                statusDescricao = PedidoProjecao.DescricaoStatus(novoStatus),
                mensagem = "SITUACAO DO PEDIDO ATUALIZADA PARA '" + PedidoProjecao.DescricaoStatus(novoStatus).ToUpper() + "'."
            });
        }

        // ALTERAR ATENDIMENTO
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAtendimento(int id, AtendimentoPut dto)
        {
            // VERIFICAR SE EXISTE O ATENDIMENTO
            // ADICIONADO: ThenInclude(IditemNavigation) PARA SABER SE CADA ITEM E PRODUTO ("P") OU SERVICO ("S")
            var atendimento = await _context.Atendimentos
                .Include(a => a.Atendimentoitems)
                    .ThenInclude(i => i.IditemNavigation)
                .FirstOrDefaultAsync(a => a.Idatendimento == id);

            if (atendimento == null)
            {
                return NotFound(new
                {
                    mensagem = "ATENDIMENTO NÃO LOCALIZADO"
                });
            }

            // ADICIONADO: VALIDACOES
            var statusNormalizado = PedidoProjecao.NormalizarStatus(dto.StatusAtendimento);
            if (statusNormalizado == null)
            {
                return BadRequest(new { mensagem = "INFORME UM STATUS VALIDO (A, P, F OU C)!!!" });
            }

            // O STATUS TEM FLUXO PROPRIO (COM DEVOLUCAO DE ESTOQUE NO CANCELAMENTO): USE PUT /api/pedidos/{id}/status
            if (statusNormalizado != atendimento.StatusAtendimento)
            {
                return BadRequest(new { mensagem = "PARA MUDAR A SITUACAO USE PUT /api/pedidos/{id}/status." });
            }

            // PEDIDO CONCLUIDO OU CANCELADO NAO PODE MAIS SER ALTERADO
            if (atendimento.StatusAtendimento == "F" || atendimento.StatusAtendimento == "C")
            {
                return Conflict(new { mensagem = "PEDIDO CONCLUIDO OU CANCELADO NAO PODE SER ALTERADO." });
            }

            var itensRecebidos = dto.Itens
                .Select(i => (i.IdItem, i.IdFuncionario, i.Quantidade, i.ValorUnitario))
                .ToList();

            var erroValidacao = ValidarItens(itensRecebidos);
            if (erroValidacao != null)
            {
                return BadRequest(new { mensagem = erroValidacao });
            }

            if (dto.IdPessoa > 0 && !await _context.Pessoas.AnyAsync(p => p.Idpessoa == dto.IdPessoa))
            {
                return NotFound(new { mensagem = "Pessoa não localizada!!!" });
            }

            var itensJaNoAtendimento = atendimento.Atendimentoitems.Select(i => i.Iditem).ToHashSet();

            var erroReferencia = await ValidarReferencias(itensRecebidos, itensJaNoAtendimento);
            if (erroReferencia != null)
            {
                return erroReferencia;
            }

            atendimento.StatusAtendimento = statusNormalizado;

            // ADICIONADO: ATUALIZA TAMBEM A PESSOA E A DATA, QUANDO INFORMADAS
            if (dto.IdPessoa > 0)
            {
                atendimento.Idpessoa = dto.IdPessoa;
            }

            if (dto.DataAtendimento != default)
            {
                atendimento.DataAtendimento = dto.DataAtendimento;
            }

            // CORRIGIDO: O ITEM AGORA E IDENTIFICADO SO PELO IdItem, IGUAL A PK DO BANCO (idatendimento + iditem).
            // ANTES ERA (IdItem + IdFuncionario) E MANDAR O MESMO ITEM COM OUTRO FUNCIONARIO DAVA ERRO DE CHAVE DUPLICADA.
            // O FUNCIONARIO PASSA A SER SO UM DADO DO ITEM, QUE PODE SER ALTERADO.
            var idsRecebidos = dto.Itens.Select(i => i.IdItem).ToHashSet();

            //comparando os ids recebido pelo dto com os ids vim do banco de dados. os que nao vieram no dto serao removidos
            var itensRemover = atendimento.Atendimentoitems
                .Where(i => !idsRecebidos.Contains(i.Iditem))
                .ToList();

            // ADICIONADO: AO REMOVER UM PRODUTO, DEVOLVE A QUANTIDADE AO ESTOQUE (A TRIGGER SO SABE BAIXAR)
            foreach (var removido in itensRemover)
            {
                if (removido.IditemNavigation.TipoItem == "P")
                {
                    var estoque = await _context.Estoques
                        .FirstOrDefaultAsync(e => e.Iditem == removido.Iditem);

                    if (estoque != null)
                    {
                        estoque.QuantidadeEstoque = estoque.QuantidadeEstoque + removido.QuantidadeItens;
                    }
                }
            }

            //exclui do banco para o atendimento o item que nao veio pelo dto
            _context.Atendimentoitems.RemoveRange(itensRemover);

            //pecorrer os itens vendo do dto
            foreach (var itemDto in dto.Itens)
            {
                //busca do banco de dados os itens do atendimento passado por parametro
                var itemExistente = atendimento.Atendimentoitems
                    .FirstOrDefault(i => i.Iditem == itemDto.IdItem);

                //verifica se existe
                //caso existe atualiza a quantidade e o valor unitario
                if (itemExistente != null)
                {
                    // ADICIONADO: SE FOR PRODUTO, ACERTA O ESTOQUE PELA DIFERENCA DE QUANTIDADE
                    // (VENDEU 2 E AGORA SAO 5 => BAIXA 3 / VENDEU 5 E AGORA SAO 2 => DEVOLVE 3)
                    if (itemExistente.IditemNavigation.TipoItem == "P")
                    {
                        var estoque = await _context.Estoques
                            .FirstOrDefaultAsync(e => e.Iditem == itemExistente.Iditem);

                        int diferenca = itemDto.Quantidade - itemExistente.QuantidadeItens;

                        if (estoque == null || estoque.QuantidadeEstoque - diferenca < 0)
                        {
                            return Conflict(new
                            {
                                mensagem = "ESTOQUE INSUFICIENTE PARA AUMENTAR A QUANTIDADE DO ITEM " + itemDto.IdItem + "!!!"
                            });
                        }

                        estoque.QuantidadeEstoque = estoque.QuantidadeEstoque - diferenca;
                    }

                    itemExistente.Idfuncionario = itemDto.IdFuncionario;
                    itemExistente.QuantidadeItens = itemDto.Quantidade;
                    itemExistente.ValorunitarioEntrada = itemDto.ValorUnitario;
                }
                else
                {
                    // ADICIONADO: ITEM NOVO. CONFERE O ESTOQUE (A TRIGGER BAIXA NO INSERT)
                    var erroEstoque = await ValidarEstoque(itemDto.IdItem, itemDto.Quantidade);
                    if (erroEstoque != null)
                    {
                        return erroEstoque;
                    }

                    //caso não exista no banco de dados cria um novo item ao pedido
                    atendimento.Atendimentoitems.Add(new Atendimentoitem
                    {
                        Idatendimento = atendimento.Idatendimento,
                        Iditem = itemDto.IdItem,
                        Idfuncionario = itemDto.IdFuncionario,
                        QuantidadeItens = itemDto.Quantidade,
                        ValorunitarioEntrada = itemDto.ValorUnitario
                    });

                }
            }

            //salva as alterações no banco de dados
            // ADICIONADO: try/catch. UM SaveChanges GRAVA ATENDIMENTO, ITENS E ESTOQUE NA MESMA TRANSACAO
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new
                {
                    mensagem = "ERRO AO ALTERAR",
                    erro = ex.InnerException?.Message ?? ex.Message
                });
            }

            //nao retona nada
            return NoContent();

        }// fim do putatendimento

        // EXCLUIR ATENDIMENTO
        [HttpDelete("{ID}")]
        public async Task<IActionResult> DeleteAtendimento(int id)
        {
            // VERIFICAR SE EXISTE O ATENDIMENTO
            // ADICIONADO: ThenInclude(IditemNavigation) PARA SABER SE CADA ITEM E PRODUTO OU SERVICO
            var atendimento = await _context.Atendimentos
                .Include(a => a.Atendimentoitems)
                    .ThenInclude(i => i.IditemNavigation)
                .FirstOrDefaultAsync(a => a.Idatendimento == id);

            // CASO NÃO LOCALIZE O ATENDIMENTO, RETORNE A MENSAGEM
            if (atendimento == null)
            {
                return NotFound(new
                {
                    mensagem = "ATENDIMENTO NÃO LOCALIZADO"
                });
            }

            // ADICIONADO: DEVOLVE AO ESTOQUE OS PRODUTOS DO ATENDIMENTO (A TRIGGER HAVIA BAIXADO NO INSERT)
            // CORRIGIDO: SE O PEDIDO JA FOI CANCELADO, O ESTOQUE JA VOLTOU. NAO DEVOLVE DE NOVO
            foreach (var item in atendimento.Atendimentoitems)
            {
                if (atendimento.StatusAtendimento != "C" && item.IditemNavigation.TipoItem == "P")
                {
                    var estoque = await _context.Estoques
                        .FirstOrDefaultAsync(e => e.Iditem == item.Iditem);

                    if (estoque != null)
                    {
                        estoque.QuantidadeEstoque = estoque.QuantidadeEstoque + item.QuantidadeItens;
                    }
                }
            }

            // EXCLUI OS ITENS DO ATENDIMENTO LOCALIZADO NA TABELA AtendimentoItem
            _context.Atendimentoitems.RemoveRange(atendimento.Atendimentoitems);

            // EXCLUI O ATENDIMENTO LOCALIZADO NA TABELA Atendimento
            _context.Atendimentos.RemoveRange(atendimento);

            // CONFIRMA AS EXCLUSÕES (ITENS, ATENDIMENTO E ESTOQUE NA MESMA TRANSACAO)
            // ADICIONADO: try/catch
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest(new
                {
                    mensagem = "ERRO AO EXCLUIR",
                    erro = ex.InnerException?.Message ?? ex.Message
                });
            }

            // NÃO RETORNA NADA!
            return NoContent();
        }// FIM DeleteAtendimento
    }
}