﻿namespace AplicacaoAtividade03.DTOs
{
    // O SISTEMA NAO TEM SENHA: O CLIENTE SE IDENTIFICA COM E-MAIL + CPF
    public class ClienteIdentificarDTO
    {
        public string? Email { get; set; }
        public string? CPF { get; set; }
    }
}
