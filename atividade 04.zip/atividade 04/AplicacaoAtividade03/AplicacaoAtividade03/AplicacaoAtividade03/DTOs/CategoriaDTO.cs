﻿namespace AplicacaoAtividade03.DTOs
{
    // DTO DE ENTRADA (POST/PUT) DA CATEGORIA
    public class CategoriaDTO
    {
        public string? Categoria { get; set; }
    }

    // DTO DE SAIDA DA CATEGORIA
    public class CategoriaListDTO
    {
        public int IdCategoria { get; set; }
        public string Categoria { get; set; } = string.Empty;

        // QUANTOS ITENS (PRODUTOS E SERVICOS) USAM A CATEGORIA
        public int QuantidadeItens { get; set; }
    }
}
