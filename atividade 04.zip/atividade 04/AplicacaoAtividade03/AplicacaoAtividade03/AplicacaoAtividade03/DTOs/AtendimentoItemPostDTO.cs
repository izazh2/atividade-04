﻿namespace AplicacaoAtividade03.DTOs
{
    public class AtendimentoItemPostDTO
    {
        public int IdItem { get; set; }
        public int IdFuncionario { get; set; }
        public int Quantidade { get; set; }

        // IGNORADO NO POST: A API BUSCA O PRECO NO BANCO (PRODUTO = PRECO DE VENDA / SERVICO = PRECO)
        public decimal ValorUnitario { get; set; }
    }
}
