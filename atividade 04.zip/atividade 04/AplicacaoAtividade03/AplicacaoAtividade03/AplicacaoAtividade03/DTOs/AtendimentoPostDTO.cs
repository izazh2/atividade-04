﻿namespace AplicacaoAtividade03.DTOs
{
    public class AtendimentoPostDTO
    {
        public int IdPessoa { get; set; }

        // OPCIONAL: SE NAO VIER, A API USA A DATA DE HOJE
        public DateOnly? DataAtendimento { get; set; }

        // IGNORADO: TODO PEDIDO NOVO NASCE COMO 'A' (ABERTO). O STATUS SO MUDA PELO ENDPOINT /status
        public string? StatusAtendimento { get; set; }

        public List<AtendimentoItemPostDTO> Itens { get; set; } = new();
    }
}
