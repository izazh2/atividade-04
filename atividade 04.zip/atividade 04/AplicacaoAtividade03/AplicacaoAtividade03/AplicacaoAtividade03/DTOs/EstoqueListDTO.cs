﻿namespace AplicacaoAtividade03.DTOs
{
    // DTO DE SAIDA DA CONSULTA DE ESTOQUE (TELA 8.2.4 DO ROTEIRO)
    public class EstoqueListDTO
    {
        public int IdItem { get; set; }
        public string Item { get; set; } = string.Empty;
        public string DescricaoItem { get; set; } = string.Empty;
        public decimal Preco { get; set; }
        public decimal PrecoVenda { get; set; }
        public string Unidade { get; set; } = string.Empty;
        public int IdCategoria { get; set; }
        public string Categoria { get; set; } = string.Empty;
        public int QuantidadeEstoque { get; set; }
        public string AtivoProdutoServico { get; set; } = string.Empty;
    }
}
