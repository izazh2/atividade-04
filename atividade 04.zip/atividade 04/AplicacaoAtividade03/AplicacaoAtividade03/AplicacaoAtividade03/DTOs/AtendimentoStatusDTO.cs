﻿namespace AplicacaoAtividade03.DTOs
{
    // DTO DE ENTRADA (PUT /api/pedidos/{id}/status)
    // ACEITA O CODIGO (A, P, F, C) OU O NOME (Aberto, Em processamento, Concluido, Cancelado)
    public class AtendimentoStatusDTO
    {
        public string? Status { get; set; }
    }
}
