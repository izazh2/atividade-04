﻿namespace AplicacaoAtividade03.DTOs
{
    public class AtendimentoListDTO
    {
        public int IdAtendimento { get; set; }
        public int IdPessoa { get; set; }
        public string NomePessoa { get; set; } = string.Empty;
        public DateOnly DataAtendimento { get; set; }

        // CODIGO: A = ABERTO / P = EM PROCESSAMENTO / F = CONCLUIDO / C = CANCELADO
        public string StatusAtendimento { get; set; } = string.Empty;

        // TEXTO PARA EXIBIR NA TELA (CALCULADO A PARTIR DO CODIGO)
        public string StatusDescricao => PedidoProjecao.DescricaoStatus(StatusAtendimento);

        // SOMA DE QUANTIDADE x VALOR UNITARIO DE TODOS OS ITENS
        public decimal ValorTotal { get; set; }

        public List<AtendimentoItemListDTO> Itens { get; set; } = new();
    }
}
