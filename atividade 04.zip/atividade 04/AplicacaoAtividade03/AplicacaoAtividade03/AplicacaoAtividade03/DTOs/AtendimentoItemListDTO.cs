﻿namespace AplicacaoAtividade03.DTOs
{
    public class AtendimentoItemListDTO
    {
        public int IdAtendimento { get; set; }
        public int IdItem { get; set; }
        public string Item { get; set; } = string.Empty;
        public int IdFuncionario { get; set; }
        public string NomeFuncionario { get; set; } = string.Empty;
        public string Cargo { get; set; } = string.Empty;
        public int Quantidade { get; set; }
        public decimal ValorUnitario { get; set; }

        public decimal ValorTotal => Quantidade * ValorUnitario;
    }
}
