﻿using AplicacaoAtividade03.Models;

namespace AplicacaoAtividade03.DTOs
{
    // METODOS COMPARTILHADOS PELOS CONTROLLERS QUE DEVOLVEM PEDIDOS (ATENDIMENTOS)
    public static class PedidoProjecao
    {
        public static string DescricaoStatus(string? codigo)
        {
            return codigo switch
            {
                "A" => "Aberto",
                "P" => "Em processamento",
                "F" => "Concluído",
                "C" => "Cancelado",
                _ => codigo ?? string.Empty
            };
        }

        // ACEITA O CODIGO OU O NOME DO STATUS E DEVOLVE SEMPRE O CODIGO (OU null SE FOR INVALIDO)
        public static string? NormalizarStatus(string? status)
        {
            if (string.IsNullOrWhiteSpace(status))
                return null;

            var s = status.Trim();

            foreach (var codigo in new[] { "A", "P", "F", "C" })
            {
                if (string.Equals(codigo, s, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(DescricaoStatus(codigo), s, StringComparison.OrdinalIgnoreCase))
                {
                    return codigo;
                }
            }

            if (string.Equals(s, "Concluido", StringComparison.OrdinalIgnoreCase)) return "F";
            if (string.Equals(s, "Finalizado", StringComparison.OrdinalIgnoreCase)) return "F";

            return null;
        }

        // CONSULTA PADRAO: PEDIDO + CLIENTE + ITENS (COM FUNCIONARIO E CARGO) + VALOR TOTAL
        public static IQueryable<AtendimentoListDTO> ProjetarPedidos(this IQueryable<Atendimento> consulta)
        {
            return consulta.Select(a => new AtendimentoListDTO
            {
                IdAtendimento = a.Idatendimento,
                IdPessoa = a.Idpessoa,
                NomePessoa = a.IdpessoaNavigation.Nome,
                DataAtendimento = a.DataAtendimento,
                StatusAtendimento = a.StatusAtendimento,
                ValorTotal = a.Atendimentoitems.Sum(i => i.QuantidadeItens * i.ValorunitarioEntrada),
                Itens = a.Atendimentoitems
                    .Select(i => new AtendimentoItemListDTO
                    {
                        IdAtendimento = i.Idatendimento,
                        IdItem = i.Iditem,
                        Item = i.IditemNavigation.Item1,
                        IdFuncionario = i.Idfuncionario,
                        NomeFuncionario = i.IdfuncionarioNavigation.IdpessoaNavigation.Nome,
                        Cargo = i.IdfuncionarioNavigation.Cargo,
                        Quantidade = i.QuantidadeItens,
                        ValorUnitario = i.ValorunitarioEntrada
                    }).ToList()
            });
        }
    }
}
